package org.libvirt.jna;

import com.sun.jna.PointerType;

/**
 * Pointer class to provide type safety to the jna interface.
 */
public class InterfacePointer extends PointerType {
}
