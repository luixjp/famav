package org.libvirt.jna;

import com.sun.jna.PointerType;

public class NetworkFilterPointer extends PointerType {
}
