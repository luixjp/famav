CLASSPATH=./target/classes:./target/testclasses:/usr/share/java/jna.jar
java -classpath $CLASSPATH test

